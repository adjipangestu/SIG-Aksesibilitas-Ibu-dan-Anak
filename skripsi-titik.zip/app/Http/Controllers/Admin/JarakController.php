<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;

class JarakController extends Controller
{
    public function index()
    {
        $kecamatan = DB::table('kecamatan')->get();
        $data_faskes = DB::table('datafaskes')->get();

        return view('admin.jarak.index', ['kecamatan' => $kecamatan, 'data_faskes' => $data_faskes]);
    }

    public function getAlamat(Request $request)
    {
        $id = $request->input('id');
        try {
            $alamat = $data_faskes = DB::table('datafaskes')->where('id_faskes', $id)->first();
            return response()->json(['data' => $alamat], 200);
        } catch (\Throwable $th) {
            return response()->json(['message' => $th->getMessages()],  $th->getStatusCode());
        }
        
    }
}
