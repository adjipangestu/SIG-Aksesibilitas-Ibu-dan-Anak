@extends('layouts.main')
@section('title', 'Input Jarak')


@push('css')
<style type="text/css">
    #map {
            height: 100%;
            width: 100%;
    }
</style>
@endpush
@section('content')
<!-- Container -->
<div class="container mt-xl-50 mt-sm-30 mt-15">
    <!-- Container -->
    <div class="container">
        <!-- Title -->
        <div class="hk-pg-header">
            <h4 class="hk-pg-title"><span class="pg-title-icon"><span class="feather-icon"><i data-feather="navigation"></i></span></span>Input Jarak</h4>
        </div>
        <!-- /Title -->

        <!-- Row -->
        <div class="row">
            <div class="col-xl-12">
                <section class="hk-sec-wrapper">
                    <div class="row">
                        <div class="col-sm">
                            <form>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="asal"><strong>Asal</strong></label>
                                        <select class="form-control" name="kecamatan" id="kecamatan">
                                            @foreach($kecamatan as $item)
                                                <option value="{{ $item->nama_kecamatan }}">{{ $item->nama_kecamatan }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="tujuan"><strong>Tujuan</strong></label>
                                        <select class="form-control" name="data_faskes" id="data_faskes">
                                            @foreach($data_faskes as $item)
                                                <option value="{{ $item->id_faskes }}">{{ $item->nama_faskes }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>

                <div id="result" class="hk-row">
                    <div class="col-sm-12">
                        <div class="card-group hk-dash-type-2">
                            <div class="card card-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between mb-5">
                                        <div>
                                            <span class="d-block font-15 text-dark font-weight-500">Jarak</span>
                                        </div>
                                    </div>
                                    <div>
                                        <span id="distance" class="d-block display-4 text-dark mb-5">0</span>
                                    </div>
                                </div>
                            </div>
                        
                            <div class="card card-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between mb-5">
                                        <div>
                                            <span class="d-block font-15 text-dark font-weight-500">Waktu Tempuh</span>
                                        </div>
                                    </div>
                                    <div>
                                        <span id="duration" class="d-block display-4 text-dark mb-5">0</span>
                                    </div>
                                </div>
                            </div>
                        
                            <div class="card card-sm">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between mb-5">
                                        <div>
                                            <span class="d-block font-15 text-dark font-weight-500">Simpan Ke Database</span>
                                        </div>
                                    </div>
                                    <div>
                                        <span class="d-block display-4 text-dark mb-5"><button id="simpan" class="btn btn-primary">Save</button></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>	
                </div>

                <div id="map" style="height: 550px"></div>
            </div>
        </div>

        
    </div>        
</div>
<!-- /Container -->
@endsection

@push('js')
<script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDPNpyLAPlS77x4m8e3NdunZAx2VcGme6w&callback=initMap&libraries=&v=weekly"
      async>
</script>

<script>
    $('#result').hide();

    function initMap() {
        const directionsService = new google.maps.DirectionsService();
        const directionsRenderer = new google.maps.DirectionsRenderer();
        const map = new google.maps.Map(document.getElementById("map"), {
            zoom: 7,
            center: { lat:-5.4286681, lng:105.2006974 },
        });
        directionsRenderer.setMap(map);

        const onChangeHandler = function () {
            calculateAndDisplayRoute(directionsService, directionsRenderer);
        };
        document.getElementById("kecamatan").addEventListener("change", onChangeHandler);
        document.getElementById("data_faskes").addEventListener("change", onChangeHandler);
    }

    function calculateAndDisplayRoute(directionsService, directionsRenderer) {
        var kecamatan = document.getElementById("kecamatan").value
        var data_faskes = document.getElementById("data_faskes").value

        var url = "{{ route('admin.jarak.get_alamat_fakses') }}" + "?id=" + data_faskes
        
        $.ajax({
            type : "GET",
            url  : url,

            data: {
                id_faskes: data_faskes,
            },
            dataType: "JSON",
            success : function (result) {
                var start = "Kec. " + kecamatan + ", Kota Bandar Lampung, Lampung, Indonesia"
                var end = result.data.alamat

                directionsService.route(
                    {
                        origin: {
                            query: start,
                        },
                        destination: {
                            query: end,
                        },
                        travelMode: google.maps.TravelMode.DRIVING,
                    },
                    (response, status) => {
                        if (status === "OK") {
                            directionsRenderer.setDirections(response);
                            console.log(response)
                            document.getElementById("distance").innerHTML = response.routes[0].legs[0].distance.text
                            document.getElementById("duration").innerHTML = response.routes[0].legs[0].duration.text
                            $('#result').show();
                        } else {
                            window.alert("Directions request failed due to " + status);
                        }
                    }
                );
            },
            error: function (error) {
                alert(error.status + ' - ' + error.statusText)
            }
        })
    }
</script>
@endpush