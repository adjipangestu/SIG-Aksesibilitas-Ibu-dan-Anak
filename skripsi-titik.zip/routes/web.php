<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Auth::routes();

Route::group(['prefix' => 'admin'], function(){
    Route::get('/home', 'Admin\HomeController@index')->name('admin.index');

    Route::group(['prefix' => 'kelola-data'], function(){
        Route::get('/jarak', 'Admin\JarakController@index')->name('admin.jarak.index');
        Route::get('/jarak/get-alamat', 'Admin\JarakController@getAlamat')->name('admin.jarak.get_alamat_fakses');
    });
});

Route::get('/home', 'HomeController@index')->name('home');
