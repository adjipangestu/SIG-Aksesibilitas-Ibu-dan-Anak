<?php $__env->startSection('title', 'Input Jarak'); ?>


<?php $__env->startSection('content'); ?>
<!-- Container -->
<div class="container mt-xl-50 mt-sm-30 mt-15">
    <!-- Container -->
    <div class="container">
        <!-- Title -->
        <div class="hk-pg-header">
            <h4 class="hk-pg-title"><span class="pg-title-icon"><span class="feather-icon"><i data-feather="navigation"></i></span></span>Input Jarak</h4>
        </div>
        <!-- /Title -->

        <!-- Row -->
        <div class="row">
            <div class="col-xl-12">
                <section class="hk-sec-wrapper">
                    <div class="row">
                        <div class="col-sm">
                            <form>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="asal"><strong>Asal</strong></label>
                                        <input class="form-control" id="asal" name="asal" placeholder="" value="" type="text">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="tujuan"><strong>Tujuan</strong></label>
                                        <input class="form-control" id="tujuan" name="tujuan" placeholder="" value="" type="text">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="map"></div>    
                </section>
            </div>
        </div>
    </div>        
</div>
<!-- /Container -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDPNpyLAPlS77x4m8e3NdunZAx2VcGme6w&callback=initMap"></script>
<script>
    function initMap() {
        const directionsService = new google.maps.DirectionsService();
        const directionsRenderer = new google.maps.DirectionsRenderer();
        const map = new google.maps.Map(document.getElementById("map"), {
            zoom: 7,
            center: { lat:-5.375130, lng:105.253640 },
        });
        directionsRenderer.setMap(map);

        const onChangeHandler = function () {
            calculateAndDisplayRoute(directionsService, directionsRenderer);
        };
        document.getElementById("asal").addEventListener("change", onChangeHandler);
        document.getElementById("tujuan").addEventListener("change", onChangeHandler);
    }

    function calculateAndDisplayRoute(directionsService, directionsRenderer) {
        directionsService.route(
            {
                origin: {
                    query: document.getElementById("asal").value,
                },
                destination: {
                    query: document.getElementById("tujuan").value,
                },
                travelMode: google.maps.TravelMode.DRIVING,
            },
            (response, status) => {
                if (status === "OK") {
                    directionsRenderer.setDirections(response);
                } else {
                    window.alert("Directions request failed due to " + status);
                }
            }
        );
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kumis/project/skripsi-titik/resources/views/admin/jarak/index.blade.php ENDPATH**/ ?>